% Here we screen parameters of the peripheral nerve model.

close all;
clear all;

rhovec = [0:0.025:1];
drvec = [0:0.01:0.4];

a1vec = 800;
gammvec = 1.125;
Vthrvec = 19.5;

N1 = numel(rhovec);
N2 = numel(drvec);
N3 = numel(a1vec);
N4 = numel(gammvec);
N5 = numel(Vthrvec);

Ntot = N1*N2*N3*N4*N5;

% create Ntot-long vectors with parameters:
rhovec2 = repmat(rhovec,[1 N2*N3*N4*N5]);
vdr = ones(N1,1)*drvec;
drvec2 = repmat(vdr(:)',[1 N3*N4*N5]);
va1 = ones(N1*N2,1)*a1vec;
a1vec2 = repmat(va1(:)',[1 N4*N5]);
vgamm = ones(N1*N2*N3,1)*gammvec;
gammvec2 = repmat(vgamm(:)',[1 N5]);
vVthr = ones(N1*N2*N3*N4,1)*Vthrvec;
Vthrvec2 = vVthr(:)';

% create tables for parameter indices:
rhoind = repmat([1:N1],[1 N2*N3*N4*N5]);
vdr = ones(N1,1)*[1:N2];
drind = repmat(vdr(:)',[1 N3*N4*N5]);
va1 = ones(N1*N2,1)*[1:N3];
a1ind = repmat(va1(:)',[1 N4*N5]);
vgamm = ones(N1*N2*N3,1)*[1:N4];
gammind = repmat(vgamm(:)',[1 N5]);
vVthr = ones(N1*N2*N3*N4,1)*[1:N5];
Vthrind = vVthr(:)';

for m = 1:Ntot
    pars(m).vel = 3.41;
    pars(m).Vmax = 110;
    pars(m).N = 100;
    pars(m).dr = drvec2(m);
    pars(m).sigrat = 1/3;
    pars(m).rho = rhovec2(m);
    pars(m).g = 0.6;
    pars(m).a1 = a1vec2(m);
    pars(m).gamm = gammvec2(m);
    pars(m).Vthr = Vthrvec2(m);
    pars(m).dt = 1e-2;
    pars(m).L = 100;
    pars(m).maxT = 400;
    pars(m).SL = 4;
    pars(m).type = 'uniform';
end

parfor m = 1:Ntot
    temp = fSpikeProp(pars(m));
    TMp(m) = temp{1};
    TDp(m) = temp{2};
    TAp{m} = temp{3};
    if numel(TAp{m})<pars(m).N
        if sum(isnan(TAp{m}))==0
            for n = numel(TAp{m})+1:pars(m).N
                TAp{m}(n) = TAp{m}(numel(TAp{m}));
            end
        end
    end
end

for m = 1:Ntot
    
    p = rhoind(m);
    q = drind(m);
    r = a1ind(m);
    s = gammind(m);
    t = Vthrind(m);
    
    delay{p,q} = TAp{m};
    TD(p,q) = TDp(m);
    TM(p,q) = TMp(m);
    
end

% Figure 4a:
figure; imagesc(TM(end:-1:1,:))
% Figure 4b:
figure; imagesc(TD(end:-1:1,:))

% figure; hold on;
% for m = 1:numel(rhovec)
%     for n = 1:pars(1).N
%         plotmat(m,n) = delay{m,1}(pars(1).N+1-n);
%     end
%     plotmat2(m,:) = hist(plotmat(m,:),[20:0.125:50]);
% end

% END OF SCRIPT