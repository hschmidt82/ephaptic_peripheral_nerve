% Here we screen parameters of the peripheral nerve model.

close all;
clear all;

dispstat('','init');
dispstat('Start.','timestamp','keepthis')


rhovec = [0.2 0.4 0.6];
drvec = [0.1:0.2:0.5];

gammvec = [0.25:0.125:4];
Vthrvec = [5:0.5:40];
a1vec = 200.*[1:10];


N1 = numel(rhovec);
N2 = numel(drvec);
N3 = numel(a1vec);
N4 = numel(gammvec);
N5 = numel(Vthrvec);

Ntot = N1*N2*N3*N4*N5;

% create Ntot-long vectors with parameters:
rhovec2 = repmat(rhovec,[1 N2*N3*N4*N5]);
vdr = ones(N1,1)*drvec;
drvec2 = repmat(vdr(:)',[1 N3*N4*N5]);
va1 = ones(N1*N2,1)*a1vec;
a1vec2 = repmat(va1(:)',[1 N4*N5]);
vgamm = ones(N1*N2*N3,1)*gammvec;
gammvec2 = repmat(vgamm(:)',[1 N5]);
vVthr = ones(N1*N2*N3*N4,1)*Vthrvec;
Vthrvec2 = vVthr(:)';

% create tables for parameter indices:
rhoind = repmat([1:N1],[1 N2*N3*N4*N5]);
vdr = ones(N1,1)*[1:N2];
drind = repmat(vdr(:)',[1 N3*N4*N5]);
va1 = ones(N1*N2,1)*[1:N3];
a1ind = repmat(va1(:)',[1 N4*N5]);
vgamm = ones(N1*N2*N3,1)*[1:N4];
gammind = repmat(vgamm(:)',[1 N5]);
vVthr = ones(N1*N2*N3*N4,1)*[1:N5];
Vthrind = vVthr(:)';

for m = 1:Ntot
    pars(m).vel = 3.41;
    pars(m).Vmax = 110;
    pars(m).N = 2;
    pars(m).dr = drvec2(m);
    pars(m).sigrat = 1/3;
    pars(m).rho = rhovec2(m);
    pars(m).g = 0.6;
    pars(m).a1 = a1vec2(m);
    pars(m).gamm = gammvec2(m);
    pars(m).Vthr = Vthrvec2(m);
    pars(m).dt = 1e-2;
    pars(m).L = 100;
    pars(m).maxT = 100;
    pars(m).SL = 4;
    pars(m).type = 'uniform';
end

parfor m = 1:Ntot
    temp = fSpikeProp(pars(m));
    TDp(m) = temp{1};
    TMp(m) = temp{2};
    TAp{m} = temp{3};
end

for m = 1:Ntot
    
    p = rhoind(m);
    q = drind(m);
    r = a1ind(m);
    s = gammind(m);
    t = Vthrind(m);
    
    if numel(TAp{m})>=pars(m).N
        delay1(p,q,r,s,t) = TAp{m}(1);
        delay2(p,q,r,s,t) = TAp{m}(2);
    else
        delay1(p,q,r,s,t) = NaN;
        delay2(p,q,r,s,t) = NaN;
    end
end

% compute cost function:
load('Fit_Delays.mat')

for n3 = 1:N3
    for n4 = 1:N4
        for n5 = 1:N5
            FM = ((delay1(:,:,n3,n4,n5)-delay1exp)./delay1exp).^2 + ((delay2(:,:,n3,n4,n5)-delay2exp)./delay2exp).^2;
            dist(n3,n4,n5) = sqrt(sum(sum( FM ))./(2*N1*N2));
        end
    end
    mina1(n3) = min(min(dist(n3,:,:)));
end

dist2 = zeros(N3,N4-2,N5-2);
dist2 = (dist(:,2:end-1,2:end-1) + dist(:,2:end-1,1:end-2) + dist(:,2:end-1,3:end) + ...
         dist(:,1:end-2,2:end-1) + dist(:,1:end-2,1:end-2) + dist(:,1:end-2,3:end) + ...
         dist(:,3:end,2:end-1) + dist(:,3:end,1:end-2) + dist(:,3:end,3:end))./9;
     
for n3 = 1:N3
    mina1b(n3) = min(min(dist2(n3,:,:)));
end

% Figure 3b:
figure; plot(a1vec,mina1b)
% Figure 3c:
figure; imagesc(squeeze(dist2(4,:,:))); caxis([0.056 0.1])

ind = find(dist==min(dist(:)));
indVthr = ceil(ind./(N3*N4));
ind2 = ind-(indVthr-1)*N3*N4;
indgamm = ceil(ind2./N3);
inda1 = ind2-(indgamm-1)*N3;

% END OF SCRIPT