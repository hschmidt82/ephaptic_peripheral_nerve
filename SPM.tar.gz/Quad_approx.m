% Here we compute perturbation profiles for APs approximated by piecewise
% quadratic functions.

close all; clear all;

% define velocity of spike:
vel = 3.1;

% define space:
x = [-0.2*vel:1e-3:1.2*vel];
xb = [-3:1e-3:19];

% define shape parameters:
Vmax = 110;
SL = 4;

t0 = 0;
t1 = @(a1) sqrt(Vmax/(2*a1));
t2 = @(a1) 2*t1(a1) + Vmax/(a1*(SL-2*t1(a1)));
t3 = SL;

a2 = @(a1) Vmax/((2*t1(a1)-SL)*(t2(a1)-SL));

x0 = t0.*vel;
x1 = @(a1) t1(a1).*vel;
x2 = @(a1) t2(a1).*vel;
x3 = t3.*vel;

% shape of spike
Vquad = @(x,a1) a1.*(x-x0).^2.*(x>x0).*(x<=x1(a1))./vel^2+...
             (Vmax-a1.*(x-2*x1(a1)).^2./vel^2).*(x>x1(a1)).*(x<=x2(a1))+...
             a2(a1).*(x-x3).^2.*(x>x2(a1)).*(x<=x3)./vel^2;

% second derivative of spike profile:
Vquadpp = @(x,a1) (2.*a1.*(x>x0).*(x<=x1(a1))-...
             2.*a1.*(x>x1(a1)).*(x<=x2(a1))+...
             2.*a2(a1).*(x>x2(a1)).*(x<=x3))./vel^2;

% cable parameters::
lambm = 1.3794;
lambn = 0.055;
taum = 0.47;
taun = 0.03;
deltaL = 0.01;

% homogenised parameters:
lambhom = ((1-deltaL)*(1/lambm^2) + deltaL*(1/lambn^2))^(-1/2);
tauhom = lambhom^2*((1-deltaL)*(taum/lambm^2) + deltaL*(taun/lambn^2));
c = vel;

% length constants defining convolution kernel:
lamb1 = (0.5*sqrt(c^2*tauhom^2+4*lambhom^2)+0.5*c*tauhom);
lamb2 = (0.5*sqrt(c^2*tauhom^2+4*lambhom^2)-0.5*c*tauhom);
lamb3 = lambhom^2/sqrt(4*lambhom^2 + c^2*tauhom^2);
 
% auxiliary function:
FF = @(x,x1,x2) lamb1.*( exp((x-x1)./lamb1) - exp((x-x2)./lamb1) ).*(x<=x1) + ...
               ( lamb1.*( 1-exp((x-x2)./lamb1) ) + lamb2.*( 1-exp(-(x-x1)./lamb2) ) ).*(x>x1).*(x<x2) + ...
               lamb2.*( exp(-(x-x2)./lamb2) - exp(-(x-x1)./lamb2) ).*(x>=x2);
           
GG = @(x,a1) -(a1/c^2).*FF(x,0,c*t1(a1)) + (a1/c^2).*FF(x,c*t1(a1),c*t2(a1)) - (a2(a1)/c^2).*FF(x,c*t2(a1),c*t3);

% parameters defining the strength of coupling:
sigrat = 1/3;
rho = 0.3;
g = 0.6;
pre = (1/2)/(1+sigrat*((1-rho)/(g^2*rho)));

% perturbation in passive axon:
pert2 = @(x,a1) pre*lamb3.*GG(x,a1);

% Figure 2a:
figure; plot(xb,Vquad(xb,1e3)); hold on; plot(xb,Vquad(xb,1e4)); plot(xb,Vquad(xb,1e5)); xlim([-2 18])

% Figure 2b:
figure; plot(xb,sign(Vquadpp(xb,1e3)).*log10(abs(Vquadpp(xb,1e3))+1)); hold on; 
        plot(xb,sign(Vquadpp(xb,1e4)).*log10(abs(Vquadpp(xb,1e4))+1));
        plot(xb,sign(Vquadpp(xb,1e5)).*log10(abs(Vquadpp(xb,1e5))+1)); 
        xlim([-2 18]); ylim([-5 5])
        
% Figure 2c:
figure; plot(xb,pert2(xb,1e3)); hold on; plot(xb,pert2(xb,1e4)); plot(xb,pert2(xb,1e5)); xlim([-2 18])


% END OF FILE