% This script generates the delay data to which we fit the model later.

close all;
clear all;

rhovec = [0.2 0.4 0.6];
drvec = [0.1:0.2:0.5];

Ntot = numel(rhovec)*numel(drvec);

rhoind = repmat([1:numel(rhovec)]',[1 numel(drvec)]);
rhoind = rhoind(:);
drind = repmat([1:numel(drvec)],[numel(rhovec) 1]);
drind = drind(:);

for m = 1:Ntot
    pars(m).dr = drvec(drind(m));
    pars(m).rho = rhovec(rhoind(m));
end

parfor m = 1:Ntot
    temp = fCable_biophys(pars(m));
    TMp(m) = temp.TM;
    TDp(m) = temp.TD;
    TAp{m} = temp.delay;
end

for m = 1:Ntot
    TD(rhoind(m),drind(m)) = TDp(m);
    TM(rhoind(m),drind(m)) = TMp(m);
    TA{rhoind(m),drind(m)} = TAp{m};
    delay1(rhoind(m),drind(m)) = TAp{m}(1);
    delay2(rhoind(m),drind(m)) = TAp{m}(2);
end

delay1exp = delay2;
delay2exp = delay1;
save('Fit_Delays.mat','delay1exp','delay2exp');

% END OF SCRIPT