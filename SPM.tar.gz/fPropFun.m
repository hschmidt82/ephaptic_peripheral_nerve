% This is a function of the SPM to be passed on to an ODE solver
function dxdt = fProp(t,posvel,pars)

    dxdt = zeros(size(posvel));

    sigrat = pars.sigrat;
    rho    = pars.rho;
    g      = pars.g;
    Vthr   = pars.Vthr;
    gamm   = pars.gamm;
    a1     = pars.a1;
    vel    = pars.vel;
    Vmax   = pars.Vmax;
    dr     = pars.dr;
    N      = pars.N;
    SL     = pars.SL;
    
    pos = posvel(1:N);
    tvel = posvel(1+N:2*N);
    
    t0 = 0;
    t1 = @(a1) sqrt(Vmax/(2*a1));
    t2 = @(a1) 2*t1(a1) + Vmax/(a1*(SL-2*t1(a1)));
    t3 = SL;

    a2 = @(a1) Vmax/((2*t1(a1)-SL)*(t2(a1)-SL));
    
    thrpos = @(a1,vel) sqrt(Vthr/a1)*vel;
    
    if strcmp(pars.type,'alpha')
        diam = real(1+(-lambertw(-1,(([1:N]-1/2)./N-1)./exp(1))-1).*dr);
    else
        diam = (1+dr.*[0:N-1]./(N-1));
    end
    
    rs = diam.^2;
    vel = vel.*diam;

    lambm = 1.93.*sqrt(-log(g)).*diam;
    lambn = 0.055.*sqrt(diam);
    taum = 0.47;
    taun = 0.03;
    deltaL = 0.01;

    lambhom = ((1-deltaL).*(1./lambm.^2) + deltaL.*(1./lambn.^2)).^(-1/2);
    tauhom = lambhom.^2.*((1-deltaL).*(taum./lambm.^2) + deltaL.*(taun./lambn.^2));

    lamb1 = @(vel,n) (0.5*sqrt(vel^2*tauhom(n)^2+4*lambhom(n)^2)-0.5*vel*tauhom(n));
    lamb2 = @(vel,n) (0.5*sqrt(vel^2*tauhom(n)^2+4*lambhom(n)^2)+0.5*vel*tauhom(n));
    lamb3 = @(vel,n) lambhom(n)^2/sqrt(4*lambhom(n)^2 + vel^2*tauhom(n)^2);

    FF = @(x,x1,x2,vel,n)   lamb1(vel,n).*( exp((x-x1)./lamb1(vel,n)) - exp((x-x2)./lamb1(vel,n)) ).*(x<=x1) + ...
                            ( lamb1(vel,n).*( 1-exp((x-x2)./lamb1(vel,n)) ) + lamb2(vel,n).*( 1-exp(-(x-x1)./lamb2(vel,n)) ) ).*(x>x1).*(x<x2) + ...
                            lamb2(vel,n).*( exp(-(x-x2)./lamb2(vel,n)) - exp(-(x-x1)./lamb2(vel,n)) ).*(x>=x2);

    pert = @(x,a1,vel,n) - (a1/vel^2).*FF(x,0,vel*t1(a1),vel,n) + (a1/vel^2).*FF(x,vel*t1(a1),vel*t2(a1),vel,n) - (a2(a1)/vel^2).*FF(x,vel*t2(a1),vel*SL,vel,n);
    
    for p = 1:N
        interact(p) = 0;
        for q = 1:N
            interact(p) = interact(p) + (rs(q)/sum(rs))/(1+sigrat*((1-rho)/(g^2*rho))).*lamb3(tvel(q),p).*pert(+thrpos(a1,tvel(p))-pos(p)+pos(q),a1,tvel(q),p);
        end
        dpos(p) = vel(p)*(1+interact(p)/(gamm*Vthr));
        dpos(p) = max(min(dpos(p),100*vel(p)),0.01*vel(p));
        dvel(p) = (dpos(p) - tvel(p));
    end
    
dxdt = [dpos dvel]';


end
% END OF FUNCTION