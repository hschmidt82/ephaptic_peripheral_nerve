function out = fSpikeProp_large(pars)

vel = pars.vel;
N = pars.N;
maxT = pars.maxT;
dr = pars.dr;
diam = (1+dr.*[0:N-1]./(N-1));
vel = vel.*diam;

% time-step the SPM:

function [position,isterminal,direction] = arriveEventsFcn(t,y)
    M = numel(y)/2;
    for m = 1:M
      position(m) = min(y(m))-100; % The value that we want to be zero
      isterminal(m) = 1.*(m==1);  % Halt integration 
      direction(m) = 0;   % The zero can be approached from either direction
    end
end

options = odeset('Events',@arriveEventsFcn,'AbsTol',1e-5,'RelTol',1e-3);
[t,y,te,ye,ie] = ode45(@(t,y) fPropFun(t,y,pars), [0 maxT], [zeros(1,N) vel], options);

if numel(te>=N)
    TM = mean(te);
    TD = std(te);
    ty = y;
    tt = t;
else
    TM = NaN;
    TD = NaN;
    te = NaN(N,1);
    ty = NaN(2*N,1);
    tt = NaN(size(t));
end

out{1} = TM;
out{2} = TD;
out{3} = te;
out{4} = ty;
out{5} = tt;

end

% END OF FUNCTION