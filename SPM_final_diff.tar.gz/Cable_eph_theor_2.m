% Here we test the theory about the perturbation profile in a passive fibre
% induced by an action potential in a neighbouring fibre.

close all; clear all;

load('Cable_passive.mat')

N = numel(fold);

d = 3;
lambm = 1.3794*d;
lambn = 0.055*sqrt(d);
taum = 0.47;
taun = 0.03;
deltaL = 0.01;

lambhom = ((1-deltaL)*(1/lambm^2) + deltaL*(1/lambn^2))^(-1/2);
tauhom = lambhom^2*((1-deltaL)*(taum/lambm^2) + deltaL*(taun/lambn^2));
c = 3.1;
sigrat = 1/3;
rho = 0.3;
g = 0.6;
pre = -(1/(1+d^2))/(1+sigrat*((1-rho)/(g^2*rho)));

scale = 10;
lamb1 = (0.5*sqrt(c^2*tauhom^2+4*lambhom^2)-0.5*c*tauhom)*scale;
lamb2 = (0.5*sqrt(c^2*tauhom^2+4*lambhom^2)+0.5*c*tauhom)*scale;
lamb3 = lambhom^2/sqrt(4*lambhom^2 + c^2*tauhom^2)*scale;

fold2 = zeros(size(fold));
fold3 = fold2;
fold4 = fold2;

x = [-N/2+1/2:1:N/2-1/2];
x2 = sort([x 0]);
kernel = lamb3.*( exp(x./lamb2).*(x<0) + exp(-x./lamb1).*(x>0) );
kernel2 = lamb3.*( exp(x2./lamb2).*(x2<0) + exp(-x2./lamb1).*(x2>=0) );
foldk = 1.*real(ifftshift(ifft(fft(unfold').*fft(kernel))));

% Figure 1b:
figure; plot(fold(end:-1:1)-fold(800)); hold on; plot(pre.*foldk(end:-1:1),'r');

% Figure 1c:
figure; plot(x2./scale,kernel2./scale); xlim([-5 5])

x = [0.2:0.01:5];
for m=1:numel(x); y(m) = fCable_eph_theor_2(x(m)); end
figure; plot(x,y/y(find(x==1)))

% END OF FILE