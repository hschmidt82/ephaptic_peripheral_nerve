% Script that runs a parameter sweep of the biophysical model at N = 10.

dr = 0.3;
rho = 0.9;

for m = 1:numel(dr)
    for n = 1:numel(rho)
        pars.dr = dr(m);
        pars.rho = rho(n);
        cc{m,n} = fCable_biophys3(pars);
    end
end

N = 1e1;
dx = 1e-1;
L = 1e2;
r = 1+dr.*(1/(N-1)).*[0:N-1];
dn = round(0.2*r./dx);
seg = round(L/dx./dn);
figure; hold on;
for m = 1:10
    plot([dx*dn(m):dx*dn(m):L],cc{1}.track{m}(1:seg(m)),'Color',[0 112/255 189/255]);
end

% END OF SCRIPT