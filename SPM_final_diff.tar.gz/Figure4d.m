% Here we plot the 2D histograms of Figures4/5d.

close all; clear all;

load('Fig4cdrev_delay_N200.mat')
dr = 0.1;
N = 200;
drv = 1 + dr.*[0:N-1]./(N-1);

% choose elements in delay corresponding to \rho = 0, 0.8, 0.85, 0.87
indp = [1 161 171 175];

Nd = 41;
Nv = 41;

spand = dr;
spanv = 20;
mind = 1;
minv = 25;

dv = mind + spand.*([0:Nd-1]./(Nd-1));
vv = minv + spanv.*([0:Nv-1]./(Nv-1));

for p = 1:3
    histmat = zeros(Nd,Nv);
    for m = 1:N
        dind = 1+floor((drv(N+1-m)-mind)*(Nd-1)/spand+0.5);
        vind = 1+floor((delay{indp(p)}(m)-minv)*(Nv-1)/spanv+0.5);
        histmat(Nd+1-dind,vind) = histmat(Nd+1-dind,vind) + 1;
    end
    figure; imagesc(histmat); colorbar;
end

spand = dr;
spanv = 60;
mind = 1;
minv = 25;

dv = mind + spand.*([0:Nd-1]./(Nd-1));
vv = minv + spanv.*([0:Nv-1]./(Nv-1));

histmat = zeros(Nd,Nv);
for m = 1:N
        dind = 1+floor((drv(N+1-m)-mind)*(Nd-1)/spand+0.5);
        vind = 1+floor((delay{indp(4)}(m)-minv)*(Nv-1)/spanv+0.5);
        histmat(Nd+1-dind,vind) = histmat(Nd+1-dind,vind) + 1;
end
figure; imagesc(histmat); colorbar;




% END OF FILE