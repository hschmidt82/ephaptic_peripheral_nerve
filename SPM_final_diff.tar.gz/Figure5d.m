% Here we plot the 2D histograms of Figures4/5d.

close all; clear all;

load('Fig5cdrev_delay_N200.mat')
dr = 0.01;
N = 200;
drv = real(1+(-lambertw(-1,(([1:N]-1/2)./N-1)./exp(1))-1).*dr);

% choose elements in delay corresponding to \rho = 0, 0.8, 0.85, 0.87
indp = [1 151 156 161];

Nd = 41;
Nv = 41;

spand = 10*dr;
spanv = 30;
mind = 1;
minv = 25;

dv = mind + spand.*([0:Nd-1]./(Nd-1));
vv = minv + spanv.*([0:Nv-1]./(Nv-1));

for p = 1:3
    histmat = zeros(Nd,Nv);
    for m = 1:N
        dind = 1+floor((drv(N+1-m)-mind)*(Nd-1)/spand+0.5);
        vind = 1+floor((delay{indp(p)}(m)-minv)*(Nv-1)/spanv+0.5);
        histmat(Nd+1-dind,vind) = histmat(Nd+1-dind,vind) + 1;
    end
    figure; imagesc(histmat); colorbar;
end

spand = 10*dr;
spanv = 50;
mind = 1;
minv = 25;

dv = mind + spand.*([0:Nd-1]./(Nd-1));
vv = minv + spanv.*([0:Nv-1]./(Nv-1));

histmat = zeros(Nd,Nv);
for m = 1:N
    dind = 1+floor((drv(N+1-m)-mind)*(Nd-1)/spand+0.5);
    vind = 1+floor((delay{indp(4)}(m)-minv)*(Nv-1)/spanv+0.5);
    histmat(Nd+1-dind,vind) = histmat(Nd+1-dind,vind) + 1;
end
figure; imagesc(histmat); colorbar;




% END OF FILE