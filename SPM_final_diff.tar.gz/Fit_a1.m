% Here we compute perturbation profiles for APs approximated by piecewise
% quadratic functions.

close all; clear all;

% define velocity of spike:
vel = 3.1;

% define space:
x = [-0.2*vel:1e-3:1.2*vel];
xb = [-3:1e-3:19];

% define shape parameters:
Vmax = 110;
SL = 4;

t0 = 0;
t1 = @(a1) sqrt(Vmax/(2*a1));
t2 = @(a1) 2*t1(a1) + Vmax/(a1*(SL-2*t1(a1)));
t3 = SL;

a2 = @(a1) Vmax/((2*t1(a1)-SL)*(t2(a1)-SL));

x0 = t0.*vel;
x1 = @(a1) t1(a1).*vel;
x2 = @(a1) t2(a1).*vel;
x3 = t3.*vel;

% shape of spike
Vquad = @(x,a1) a1.*(x-x0).^2.*(x>x0).*(x<=x1(a1))./vel^2+...
             (Vmax-a1.*(x-2*x1(a1)).^2./vel^2).*(x>x1(a1)).*(x<=x2(a1))+...
             a2(a1).*(x-x3).^2.*(x>x2(a1)).*(x<=x3)./vel^2;

load('Fit_Profile');
xc = [0:0.1:20];
xp = [0:0.001:5];
ga = [1e1:1e1:2e3];
profile2 = profile(1:51); % we only fit rising phase
xc2 = [0:0.1:5];

for m = 1:numel(xp)
    for n = 1:numel(ga)
%     diff(m,n) = sqrt(sum((profile-Vquad(xc-xp(m),ga(n))').^2));
    diff(m,n) = sqrt(sum((profile2-Vquad(xc2-xp(m),ga(n))').^2));
    end
end

figure; plot(ga,min(diff,[],1)); ylim([10 100])
figure; plot(Vquad(xc-3,740)); hold on; plot(profile); xlim([0 200])

% END OF FILE