% Here we screen parameters of the peripheral nerve model.

close all;
clear all;

rhovec = [0.5 0.6 0.7 0.8 0.9];
drvec = [0.1 0.2 0.3];

a1vec = 740;
gammvec = [2.2:0.0125:3.2];
Vthrvec = [6:0.05:10];


N1 = numel(rhovec);
N2 = numel(drvec);
N3 = numel(a1vec);
N4 = numel(gammvec);
N5 = numel(Vthrvec);

Ntot = N1*N2*N3*N4*N5;

% create Ntot-long vectors with parameters:
rhovec2 = repmat(rhovec,[1 N2*N3*N4*N5]);
vdr = ones(N1,1)*drvec;
drvec2 = repmat(vdr(:)',[1 N3*N4*N5]);
va1 = ones(N1*N2,1)*a1vec;
a1vec2 = repmat(va1(:)',[1 N4*N5]);
vgamm = ones(N1*N2*N3,1)*gammvec;
gammvec2 = repmat(vgamm(:)',[1 N5]);
vVthr = ones(N1*N2*N3*N4,1)*Vthrvec;
Vthrvec2 = vVthr(:)';

% create tables for parameter indices:
rhoind = repmat([1:N1],[1 N2*N3*N4*N5]);
vdr = ones(N1,1)*[1:N2];
drind = repmat(vdr(:)',[1 N3*N4*N5]);
va1 = ones(N1*N2,1)*[1:N3];
a1ind = repmat(va1(:)',[1 N4*N5]);
vgamm = ones(N1*N2*N3,1)*[1:N4];
gammind = repmat(vgamm(:)',[1 N5]);
vVthr = ones(N1*N2*N3*N4,1)*[1:N5];
Vthrind = vVthr(:)';

for m = 1:Ntot
    pars(m).vel = 3.1;
    pars(m).Vmax = 110;
    pars(m).N = 10;
    pars(m).dr = drvec2(m);
    pars(m).sigrat = 1/3;
    pars(m).rho = rhovec2(m);
    pars(m).g = 0.6;
    pars(m).a1 = a1vec2(m);
    pars(m).gamm = gammvec2(m);
    pars(m).Vthr = Vthrvec2(m);
    pars(m).dt = 1e-2;
    pars(m).L = 100;
    pars(m).maxT = 300;
    pars(m).SL = 4;
    pars(m).type = 'uniform';
end

parfor m = 1:Ntot
    temp = fSpikeProp(pars(m));
    TDp(m) = temp{1};
    TMp(m) = temp{2};
    TAp{m} = temp{3};
end

delaya = zeros(pars(1).N,N1,N2,N3,N4,N5);

for m = 1:Ntot
    
    p = rhoind(m);
    q = drind(m);
    r = a1ind(m);
    s = gammind(m);
    t = Vthrind(m);
    
    if numel(TAp{m})>=pars(m).N
        delaya(:,p,q,r,s,t) = TAp{m};
    else
        delaya(:,p,q,r,s,t) = NaN(pars(1).N,1);
    end
end

% compute cost function:
load('Fit_Delays_N10_v2.mat')

for n3 = 1:N3
    for n4 = 1:N4
        for n5 = 1:N5
            FM = ((delaya(10:-1:1,:,:,n3,n4,n5)-delayexp)./delayexp).^2;
            dist(n3,n4,n5) = sqrt(sum(sum(sum( FM )))./(pars(1).N*N1*N2));
            distb(n3,n4,n5) = sqrt(sum(sum(sum( FM(:,1:4,:) )))./(pars(1).N*N1*N2));
        end
    end
    mina1(n3) = min(min(dist(n3,:,:)));
end

dist(isnan(dist)) = 0.2;
figure; imagesc(squeeze(dist)); caxis([0.08 0.2]); colorbar

% END OF SCRIPTi