% Script that runs a parameter sweep of the biophysical model at N = 100.

close all; clear all;

% dr = [0.1 0.2 0.3];
% rho = [0.5 0.6 0.7 0.8 0.9];

dispstat('','init');
dispstat('','timestamp','keepthis')

dr = 0.1;
% rho = [0.8:0.01:0.9];
% rho = [0.8 0.85 0.87];
rho = [0.8:0.025:0.95];

for m = 1:numel(dr)
    for n = 1:numel(rho)
        pars.dr = dr(m);
        pars.rho = rho(n);
        cc{m,n} = fCable_biophys2(pars);
        dispstat(num2str(n),'timestamp','keepthis');
    end
end

% END OF SCRIPT