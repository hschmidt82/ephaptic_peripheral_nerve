% Here we solve the cable equation numerically.
function [out] = fCable(pars)

% define space:
dx = 10e-2; % mm
X = 14e1; % mm
l = 2e-3; % node length in mm
x = dx.*[1:ceil(X/dx)];

N = 1e1;
dr = pars.dr;
r = 1+dr.*(1/(N-1)).*[0:N-1]; % distribution of diameters
% r = 1;

g = 0.6; % g-ratio
tau = 0.47; % cable time constant ms
taun = 0.03; % node time constant ms
rm = 130; % longitudinal myelin resistance in M\Omega cm
lambc = 1.93.*r.*sqrt(-log(g)); % cable length constant in mm;
lambn = 55e-3.*sqrt(r); % node length constant in mm
rho = pars.rho;
sigrat = 1/3;

% define node positions
dn = round(0.2*r./dx); % assuming internode length = 200 x radius
sn = 5; % distance of extremal nodes from domain edge
nn = ceil((X-2*sn)./dx./dn); % number of nodes on each axon
mask = zeros(N,numel(x)); % setup mask
for o = 1:N; mask(o,sn/dx+[0:nn(o)-1].*dn(o))=1; ...
        mask(o,max(size(mask))-sn/dx)=1; 
        idn{o} = sn/dx+[0:nn(o)-1].*dn(o); 
        track{o} = zeros(1,numel(idn{o})); end; % mark node positions
trackn = zeros(N,1);
trackt = trackn;
Vtrack = 40;

% parameters:
lamb1 = lambc;
deltaL = l/dx;
lamb2 = ((1-deltaL).*(1./lambc.^2) + deltaL.*(1./lambn.^2)).^(-1/2);
tau1 = tau;
tau2 = lamb2.^2.*((1-deltaL).*(tau./lambc.^2) + deltaL.*(taun./lambn.^2));

% define time domain:
dt = 5e-5; % in ms
T = 1e2; % in ms
T = round(T./dt);

% define system variable:
V = zeros(N,numel(x));
I = zeros(N,numel(x));

% internodal segments:
tau = tau1.*ones(N,numel(x));
lamb = lamb1'*ones(1,numel(x));

% segments with node:
for o = 1:N
    tau(o,mask(o,:)==1) = tau2(o);
    lamb(o,mask(o,:)==1) = lamb2(o);
end

% HH dynamics:

% set up HH variables
Vn = zeros(N,max(sum(mask,2))+1);
m = 0.0529.*ones(size(Vn));
h = 0.5961.*ones(size(Vn));
n = 0.3177.*ones(size(Vn));
Inode = zeros(size(Vn));

% HH parameters: (2nd row: Brill et al. '77)
gNa = 120; gNa = 1200; gNa = 4800;
eNa = 115;
gK = 36; gK = 90; gK = 720;
eK = -12;
gL = 0.3; gL = 20; gL = 30;

% activation times:
ton = zeros(1,N)./dt;

% time stepping:
t = 0;
while (min(trackt)==0)&&(t<=T)
    
    t = t+1;
    
    Istim = zeros(1,N);
    for o = 1:N
%         Istim(o) = (1/r(o)^2)*1e4.*(t<1e5+ton(o)).*(t>ton(o));
        Istim(o) = (1/r(o)^2)*1e4.*(t<5e5+ton(o)).*(t>ton(o));
    end
    for o = 1:N
        Vn(o,1:nn(o)+1) = V(o,mask(o,:)==1);
    end
    
    m = m + dt.*(((2.5-0.1.*Vn) ./ (exp(2.5-0.1.*Vn) -1)).*(1-m) - ...
        (4.*exp(-Vn./18)).*m);
    h = h + dt.*(((0.07.*exp(-Vn./20))).*(1-h) - ...
        (1./(exp(3.0-0.1.*Vn)+1)).*h);
    n = n + dt.*(((0.1-0.01.*Vn) ./ (exp(1-0.1.*Vn) -1)).*(1-n) - ...
        (0.125.*exp(-Vn./80)).*n);
    
    Inode = repmat(r',[1 max(size(Inode))]).*(gNa.*m.^3.*h.*(eNa-Vn) + gK.*n.^4.*(eK-Vn))./gL;
    Inode(:,1) = Istim;
    
    for o = 1:N
        I(o,mask(o,:)==1) = Inode(o,1:nn(o)+1);
        if (trackt(o)==0)&&(V(o,1e3+sn/dx)>Vtrack)
            trackt(o) = t*dt;
        end
    end
    
    Ve = [V(:,1) V V(:,end)];
    Vxx = (Ve(:,3:end)+Ve(:,1:end-2)-2.*Ve(:,2:end-1))./dx^2;
    dV = dt.*(lamb.^2.*Vxx - lamb.^2.*repmat(sum( repmat( (r'.^2./sum(r.^2))./(1+sigrat*((1-rho)/(g^2*rho))) ,[1 numel(x)]).*Vxx,1),[N 1]) - V + I)./tau;
    
    V = V+dV;

    if mod(t,100)==0
        for p = 1:N
            if trackn(p)<nn(p)
                if sum(V(p,idn{p}(trackn(p)+1:end))>Vtrack)>0
                    idt = max(find(V(p,idn{p}(trackn(p)+1:end))>Vtrack));
                    trackn(p) = trackn(p) + idt;
                    track{p}(trackn(p))=t.*dt;
                end
            end
        end
    end
    
end

out.TM = mean(trackt);
out.TD = std(trackt);
out.delay = trackt;
out.track = track;
out.dn = dn;

end

% END OF FILE